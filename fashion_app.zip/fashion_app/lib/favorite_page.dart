import 'package:flutter/material.dart';

class FavoritePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'No Favorite Items Yet!',
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
