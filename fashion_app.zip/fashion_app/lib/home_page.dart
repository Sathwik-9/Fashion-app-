import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow, // Set app bar color
        elevation: 0, // Removes app bar shadow
        automaticallyImplyLeading: false, // Removes the default back button
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search for fashion...',
                prefixIcon: Icon(Icons.mic), // Mic icon on the left side
                suffixIcon: Icon(Icons.camera_alt), // Camera icon on the right side
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.all(10),
              ),
            ),
          ),

          // Category buttons with circular images
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: GridView.count(
              shrinkWrap: true,
              crossAxisCount: 2, // 2 items in each row
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              children: [
                // Men category with image
                CategoryCard(
                  imagePath: 'assets/img.jpg', // Replace with your image path
                  label: 'Men',
                ),
                // Women category with image
                CategoryCard(
                  imagePath: 'assets/img_1.jpg', // Replace with your image path
                  label: 'Women',
                ),
                // Footwear category with image
                CategoryCard(
                  imagePath: 'assets/img_2.jpg', // Replace with your image path
                  label: 'Footwear',
                ),
                // Accessories category with image
                CategoryCard(
                  imagePath: 'assets/img_3.jpg', // Replace with your image path
                  label: 'Accessories',
                ),
              ],
            ),
          ),

          Expanded(
            child: Center(
              child: Text(
                'Welcome to the Fashion App!',
                style: TextStyle(fontSize: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Category Card Widget
class CategoryCard extends StatelessWidget {
  final String imagePath;
  final String label;

  CategoryCard({required this.imagePath, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 40, // Circle radius
          backgroundImage: AssetImage(imagePath), // Image inside the circle
        ),
        SizedBox(height: 10),
        Text(
          label,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
